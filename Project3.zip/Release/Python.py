import re
import string


def countlist:
    grocery_list = ['Spinach', 'Radishes', 'Broccoli', 'Peas', 'Cranberries', 'Broccoli', 'Potatoes', 'Cucumbers', 'Radishes', 'Cranberries', 'Peaches', 'Zucchini', 'Potatoes', 'Cranberries', 'Cantaloupe', 'Beets', 'Cauliflower', 'Cranberries', 'Peas', 'Zucchini', 'Peas', 'Onions', 'Potatoes', 'Cauliflower', 'Spinach', 'Radishes', 'Onions', 'Zucchini', 'Cranberries', 'Peaches', 'Yams', 'Zucchini', 'Apples', 'Cucumbers', 'Broccoli', 'Cranberries', 'Beets', 'Peas', 'Cauliflower', 'Potatoes', 'Cauliflower', 'Celery', 'Cranberries', 'Limes', 'Cranberries', 'Broccoli', 'Spinach', 'Broccoli', 'Garlic', 'Cauliflower', 'Pumpkins', 'Celery', 'Peas', 'Potatoes', 'Yams', 'Zucchini', 'Cranberries', 'Cantaloupe', 'Zucchini', 'Pumpkins', 'Cauliflower', 'Yams', 'Pears', 'Peaches', 'Apples', 'Zucchini', 'Cranberries', 'Zucchini', 'Garlic', 'Broccoli','Garlic', 'Onions', 'Spinach', 'Cucumbers', 'Cucumbers', 'Garlic', 'Spinach', 'Peaches', 'Cucumbers', 'Broccoli', 'Zucchini', 'Peas', 'Celery', 'Cucumbers', 'Celery', 'Yams', 'Garlic', 'Cucumbers', 'Peas', 'Beets', 'Yams', 'Peas', 'Apples', 'Peaches', 'Garlic', 'Celery', 'Garlic', 'Cucumbers', 'Garlic', 'Apples', 'Celery', 'Zucchini', 'Cucumbers', 'Onions']

    counter = Counter(grocery_list)

    print(counter)

def countitem:
    grocery_list = ['Spinach', 'Radishes', 'Broccoli', 'Peas', 'Cranberries', 'Broccoli', 'Potatoes', 'Cucumbers', 'Radishes', 'Cranberries', 'Peaches', 'Zucchini', 'Potatoes', 'Cranberries', 'Cantaloupe', 'Beets', 'Cauliflower', 'Cranberries', 'Peas', 'Zucchini', 'Peas', 'Onions', 'Potatoes', 'Cauliflower', 'Spinach', 'Radishes', 'Onions', 'Zucchini', 'Cranberries', 'Peaches', 'Yams', 'Zucchini', 'Apples', 'Cucumbers', 'Broccoli', 'Cranberries', 'Beets', 'Peas', 'Cauliflower', 'Potatoes', 'Cauliflower', 'Celery', 'Cranberries', 'Limes', 'Cranberries', 'Broccoli', 'Spinach', 'Broccoli', 'Garlic', 'Cauliflower', 'Pumpkins', 'Celery', 'Peas', 'Potatoes', 'Yams', 'Zucchini', 'Cranberries', 'Cantaloupe', 'Zucchini', 'Pumpkins', 'Cauliflower', 'Yams', 'Pears', 'Peaches', 'Apples', 'Zucchini', 'Cranberries', 'Zucchini', 'Garlic', 'Broccoli','Garlic', 'Onions', 'Spinach', 'Cucumbers', 'Cucumbers', 'Garlic', 'Spinach', 'Peaches', 'Cucumbers', 'Broccoli', 'Zucchini', 'Peas', 'Celery', 'Cucumbers', 'Celery', 'Yams', 'Garlic', 'Cucumbers', 'Peas', 'Beets', 'Yams', 'Peas', 'Apples', 'Peaches', 'Garlic', 'Celery', 'Garlic', 'Cucumbers', 'Garlic', 'Apples', 'Celery', 'Zucchini', 'Cucumbers', 'Onions']

    count = grocery_list.count(i)

    print(count)